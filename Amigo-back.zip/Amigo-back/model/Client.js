const mongoose = require('mongoose');


const clientSchema = new mongoose.Schema({
    nom: {
        type: String,
    },
    prenom: {
        type: String,
    },
    email: {
        type: String,
    },
    tel:{
        type:Number,
       
    },
    cin: {
        type: String,
    },
    nPermis:{
        type:Number,
       
    },
    licenceTaxi:{
        type:Number,
       
    },
   
    immatr:{
        type:String,
   
    },
    numTaxi:{
        type:Number,
        
    },
    constructeur:{
        type:String,
      
    },
    model:{
        type:String,
      
    },
    annee:{
        type:Number,
       
    },
});


module.exports = mongoose.model('Client', clientSchema);
