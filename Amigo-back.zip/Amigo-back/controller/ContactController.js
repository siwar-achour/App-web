const Contact = require('../model/Contact');
const contact= async (req,res)=>{
    const contact =new Contact({
     
        nom:req.body.nom,
        prenom : req.body.prenom,
        email : req.body.email,
        message : req.body.message
    });
        try{
            const savedContact = await contact.save();
            res.send(savedContact);
        }catch(error){
            res.json({message:error});
        }
    
};
module.exports = {
   
    contact
    
 }
