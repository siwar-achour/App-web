const router = require("express").Router();
const  contactController = require('../controller/ContactController');

 router.post("/",contactController.contact);
 module.exports =router;