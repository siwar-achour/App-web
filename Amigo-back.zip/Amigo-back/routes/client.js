const router = require("express").Router();
const  clientController = require('../controller/ClientController');

 router.post("/",clientController.client);
 module.exports =router;