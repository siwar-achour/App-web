const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

app.use(cors({
  origin: "http://localhost:3000"
}));

app.get('/', (req, res) => {
  res.send('Hello, Express!');
});

// mongoose
mongoose
  .connect('mongodb+srv://admin:admin@amigo.xil8lae.mongodb.net/?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    console.log('Connection successful!');
  })
  .catch((error) => {
    console.log('Connection error:', error);
  });

const contactRoutes = require('./routes/contact');
const clientRoutes = require('./routes/client');
app.use(express.json());
app.use('/api/contact', contactRoutes);
app.use('/api/client', clientRoutes);
app.listen(3010, () => {
  console.log('The Express server is running on port 3010');
});
